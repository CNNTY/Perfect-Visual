﻿namespace Perfect_Visual_神龙信息经理辅助
{
    partial class FrMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrMain));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Lbcopy = new System.Windows.Forms.LinkLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnpwd = new System.Windows.Forms.Button();
            this.btnetkey = new System.Windows.Forms.Button();
            this.btnWIN8 = new System.Windows.Forms.Button();
            this.btnOpne = new System.Windows.Forms.Button();
            this.Setting = new System.Windows.Forms.Button();
            this.Start1 = new System.Windows.Forms.Button();
            this.btnTools = new System.Windows.Forms.Button();
            this.Start2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.DCAD_NetDisk = new System.Windows.Forms.LinkLabel();
            this.dcadGW = new System.Windows.Forms.LinkLabel();
            this.dcadIQS = new System.Windows.Forms.LinkLabel();
            this.dcadReply = new System.Windows.Forms.LinkLabel();
            this.dcad_cs = new System.Windows.Forms.LinkLabel();
            this.salesjob = new System.Windows.Forms.LinkLabel();
            this.dcadlive = new System.Windows.Forms.LinkLabel();
            this.dcad_DMSNET = new System.Windows.Forms.LinkLabel();
            this.dcadcweb = new System.Windows.Forms.LinkLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.DPAD_NetDisk = new System.Windows.Forms.LinkLabel();
            this.dpadGW = new System.Windows.Forms.LinkLabel();
            this.dpadIQS = new System.Windows.Forms.LinkLabel();
            this.dpad_Opp = new System.Windows.Forms.LinkLabel();
            this.dpadReply = new System.Windows.Forms.LinkLabel();
            this.dpadSB = new System.Windows.Forms.LinkLabel();
            this.dpcacweb = new System.Windows.Forms.LinkLabel();
            this.dpad_DMSNET = new System.Windows.Forms.LinkLabel();
            this.dpadlive = new System.Windows.Forms.LinkLabel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Car_insurance = new System.Windows.Forms.LinkLabel();
            this.Email263 = new System.Windows.Forms.LinkLabel();
            this.SB_CS_pwd = new System.Windows.Forms.LinkLabel();
            this.WX = new System.Windows.Forms.LinkLabel();
            this.Importe = new System.Windows.Forms.LinkLabel();
            this.financial_IMG = new System.Windows.Forms.LinkLabel();
            this.Map = new System.Windows.Forms.LinkLabel();
            this.financial = new System.Windows.Forms.LinkLabel();
            this.TheTest = new System.Windows.Forms.LinkLabel();
            this.EnterpriseMail = new System.Windows.Forms.LinkLabel();
            this.UsedCar = new System.Windows.Forms.LinkLabel();
            this.parts = new System.Windows.Forms.LinkLabel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.BtnEadd = new System.Windows.Forms.Button();
            this.SetupMethods = new System.Windows.Forms.Button();
            this.CWEBBACK1 = new System.Windows.Forms.Button();
            this.cwebbak = new System.Windows.Forms.Button();
            this.Errinfo = new System.Windows.Forms.Button();
            this.IESetting = new System.Windows.Forms.Button();
            this.KeySetup = new System.Windows.Forms.Button();
            this.cwebkey = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.contxtMS = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.关于程序 = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Display = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel8 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel9 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.contxtMS.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.groupBox5);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox4);
            this.panel2.Name = "panel2";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Lbcopy);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // Lbcopy
            // 
            resources.ApplyResources(this.Lbcopy, "Lbcopy");
            this.Lbcopy.Name = "Lbcopy";
            this.Lbcopy.TabStop = true;
            this.Lbcopy.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Lbcopy_LinkClicked);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Name = "label2";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnpwd);
            this.groupBox5.Controls.Add(this.btnetkey);
            this.groupBox5.Controls.Add(this.btnWIN8);
            this.groupBox5.Controls.Add(this.btnOpne);
            this.groupBox5.Controls.Add(this.Setting);
            this.groupBox5.Controls.Add(this.Start1);
            this.groupBox5.Controls.Add(this.btnTools);
            this.groupBox5.Controls.Add(this.Start2);
            this.groupBox5.ForeColor = System.Drawing.Color.MediumOrchid;
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            // 
            // btnpwd
            // 
            resources.ApplyResources(this.btnpwd, "btnpwd");
            this.btnpwd.Name = "btnpwd";
            this.btnpwd.UseVisualStyleBackColor = true;
            this.btnpwd.Click += new System.EventHandler(this.btnpwd_Click);
            // 
            // btnetkey
            // 
            resources.ApplyResources(this.btnetkey, "btnetkey");
            this.btnetkey.Name = "btnetkey";
            this.btnetkey.UseVisualStyleBackColor = true;
            this.btnetkey.Click += new System.EventHandler(this.btnetkey_Click);
            // 
            // btnWIN8
            // 
            resources.ApplyResources(this.btnWIN8, "btnWIN8");
            this.btnWIN8.Name = "btnWIN8";
            this.btnWIN8.UseVisualStyleBackColor = true;
            this.btnWIN8.Click += new System.EventHandler(this.btnWIN8_Click);
            // 
            // btnOpne
            // 
            resources.ApplyResources(this.btnOpne, "btnOpne");
            this.btnOpne.Name = "btnOpne";
            this.btnOpne.UseVisualStyleBackColor = true;
            this.btnOpne.Click += new System.EventHandler(this.btnOpne_Click);
            // 
            // Setting
            // 
            resources.ApplyResources(this.Setting, "Setting");
            this.Setting.Name = "Setting";
            this.Setting.UseVisualStyleBackColor = true;
            this.Setting.Click += new System.EventHandler(this.Setting_Click);
            // 
            // Start1
            // 
            resources.ApplyResources(this.Start1, "Start1");
            this.Start1.Name = "Start1";
            this.toolTip.SetToolTip(this.Start1, resources.GetString("Start1.ToolTip"));
            this.Start1.UseVisualStyleBackColor = true;
            this.Start1.Click += new System.EventHandler(this.Start1_Click);
            // 
            // btnTools
            // 
            resources.ApplyResources(this.btnTools, "btnTools");
            this.btnTools.Name = "btnTools";
            this.toolTip.SetToolTip(this.btnTools, resources.GetString("btnTools.ToolTip"));
            this.btnTools.UseVisualStyleBackColor = true;
            this.btnTools.Click += new System.EventHandler(this.btnTools_Click);
            // 
            // Start2
            // 
            resources.ApplyResources(this.Start2, "Start2");
            this.Start2.Name = "Start2";
            this.toolTip.SetToolTip(this.Start2, resources.GetString("Start2.ToolTip"));
            this.Start2.UseVisualStyleBackColor = true;
            this.Start2.Click += new System.EventHandler(this.Start2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.DCAD_NetDisk);
            this.groupBox1.Controls.Add(this.dcadGW);
            this.groupBox1.Controls.Add(this.dcadIQS);
            this.groupBox1.Controls.Add(this.dcadReply);
            this.groupBox1.Controls.Add(this.dcad_cs);
            this.groupBox1.Controls.Add(this.salesjob);
            this.groupBox1.Controls.Add(this.dcadlive);
            this.groupBox1.Controls.Add(this.dcad_DMSNET);
            this.groupBox1.Controls.Add(this.dcadcweb);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // DCAD_NetDisk
            // 
            resources.ApplyResources(this.DCAD_NetDisk, "DCAD_NetDisk");
            this.DCAD_NetDisk.BackColor = System.Drawing.SystemColors.Control;
            this.DCAD_NetDisk.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.DCAD_NetDisk.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.DCAD_NetDisk.Name = "DCAD_NetDisk";
            this.DCAD_NetDisk.TabStop = true;
            this.DCAD_NetDisk.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.DCAD_NetDisk_LinkClicked);
            // 
            // dcadGW
            // 
            resources.ApplyResources(this.dcadGW, "dcadGW");
            this.dcadGW.BackColor = System.Drawing.SystemColors.Control;
            this.dcadGW.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dcadGW.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dcadGW.Name = "dcadGW";
            this.dcadGW.TabStop = true;
            this.dcadGW.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dcadGW_LinkClicked);
            // 
            // dcadIQS
            // 
            resources.ApplyResources(this.dcadIQS, "dcadIQS");
            this.dcadIQS.BackColor = System.Drawing.SystemColors.Control;
            this.dcadIQS.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dcadIQS.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dcadIQS.Name = "dcadIQS";
            this.dcadIQS.TabStop = true;
            this.dcadIQS.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dcadIQS_LinkClicked);
            // 
            // dcadReply
            // 
            resources.ApplyResources(this.dcadReply, "dcadReply");
            this.dcadReply.BackColor = System.Drawing.SystemColors.Control;
            this.dcadReply.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dcadReply.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dcadReply.Name = "dcadReply";
            this.dcadReply.TabStop = true;
            this.dcadReply.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dcadReply_LinkClicked);
            // 
            // dcad_cs
            // 
            resources.ApplyResources(this.dcad_cs, "dcad_cs");
            this.dcad_cs.BackColor = System.Drawing.SystemColors.Control;
            this.dcad_cs.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dcad_cs.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dcad_cs.Name = "dcad_cs";
            this.dcad_cs.TabStop = true;
            this.dcad_cs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dcad_cs_LinkClicked);
            // 
            // salesjob
            // 
            resources.ApplyResources(this.salesjob, "salesjob");
            this.salesjob.BackColor = System.Drawing.SystemColors.Control;
            this.salesjob.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.salesjob.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.salesjob.Name = "salesjob";
            this.salesjob.TabStop = true;
            this.salesjob.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.salesjob_LinkClicked);
            // 
            // dcadlive
            // 
            resources.ApplyResources(this.dcadlive, "dcadlive");
            this.dcadlive.BackColor = System.Drawing.SystemColors.Control;
            this.dcadlive.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dcadlive.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dcadlive.Name = "dcadlive";
            this.dcadlive.TabStop = true;
            this.dcadlive.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dcadlive_LinkClicked);
            // 
            // dcad_DMSNET
            // 
            resources.ApplyResources(this.dcad_DMSNET, "dcad_DMSNET");
            this.dcad_DMSNET.BackColor = System.Drawing.SystemColors.Control;
            this.dcad_DMSNET.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dcad_DMSNET.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dcad_DMSNET.Name = "dcad_DMSNET";
            this.dcad_DMSNET.TabStop = true;
            this.toolTip.SetToolTip(this.dcad_DMSNET, resources.GetString("dcad_DMSNET.ToolTip"));
            this.dcad_DMSNET.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dcad_DMSNET_LinkClicked);
            // 
            // dcadcweb
            // 
            resources.ApplyResources(this.dcadcweb, "dcadcweb");
            this.dcadcweb.BackColor = System.Drawing.SystemColors.Control;
            this.dcadcweb.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dcadcweb.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dcadcweb.Name = "dcadcweb";
            this.dcadcweb.TabStop = true;
            this.toolTip.SetToolTip(this.dcadcweb, resources.GetString("dcadcweb.ToolTip"));
            this.dcadcweb.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dcadcweb_LinkClicked);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.DPAD_NetDisk);
            this.groupBox2.Controls.Add(this.dpadGW);
            this.groupBox2.Controls.Add(this.dpadIQS);
            this.groupBox2.Controls.Add(this.dpad_Opp);
            this.groupBox2.Controls.Add(this.dpadReply);
            this.groupBox2.Controls.Add(this.dpadSB);
            this.groupBox2.Controls.Add(this.dpcacweb);
            this.groupBox2.Controls.Add(this.dpad_DMSNET);
            this.groupBox2.Controls.Add(this.dpadlive);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // DPAD_NetDisk
            // 
            resources.ApplyResources(this.DPAD_NetDisk, "DPAD_NetDisk");
            this.DPAD_NetDisk.BackColor = System.Drawing.SystemColors.Control;
            this.DPAD_NetDisk.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.DPAD_NetDisk.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.DPAD_NetDisk.Name = "DPAD_NetDisk";
            this.DPAD_NetDisk.TabStop = true;
            this.DPAD_NetDisk.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.DPAD_NetDisk_LinkClicked);
            // 
            // dpadGW
            // 
            resources.ApplyResources(this.dpadGW, "dpadGW");
            this.dpadGW.BackColor = System.Drawing.SystemColors.Control;
            this.dpadGW.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dpadGW.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dpadGW.Name = "dpadGW";
            this.dpadGW.TabStop = true;
            this.dpadGW.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dpadGW_LinkClicked);
            // 
            // dpadIQS
            // 
            resources.ApplyResources(this.dpadIQS, "dpadIQS");
            this.dpadIQS.BackColor = System.Drawing.SystemColors.Control;
            this.dpadIQS.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dpadIQS.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dpadIQS.Name = "dpadIQS";
            this.dpadIQS.TabStop = true;
            this.dpadIQS.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dpadIQS_LinkClicked);
            // 
            // dpad_Opp
            // 
            resources.ApplyResources(this.dpad_Opp, "dpad_Opp");
            this.dpad_Opp.BackColor = System.Drawing.SystemColors.Control;
            this.dpad_Opp.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dpad_Opp.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dpad_Opp.Name = "dpad_Opp";
            this.dpad_Opp.TabStop = true;
            this.dpad_Opp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dpad_Opp_LinkClicked);
            // 
            // dpadReply
            // 
            resources.ApplyResources(this.dpadReply, "dpadReply");
            this.dpadReply.BackColor = System.Drawing.SystemColors.Control;
            this.dpadReply.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dpadReply.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dpadReply.Name = "dpadReply";
            this.dpadReply.TabStop = true;
            this.dpadReply.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dpadReply_LinkClicked);
            // 
            // dpadSB
            // 
            resources.ApplyResources(this.dpadSB, "dpadSB");
            this.dpadSB.BackColor = System.Drawing.SystemColors.Control;
            this.dpadSB.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dpadSB.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dpadSB.Name = "dpadSB";
            this.dpadSB.TabStop = true;
            this.dpadSB.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dpadSB_LinkClicked);
            // 
            // dpcacweb
            // 
            resources.ApplyResources(this.dpcacweb, "dpcacweb");
            this.dpcacweb.BackColor = System.Drawing.SystemColors.Control;
            this.dpcacweb.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dpcacweb.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dpcacweb.Name = "dpcacweb";
            this.dpcacweb.TabStop = true;
            this.toolTip.SetToolTip(this.dpcacweb, resources.GetString("dpcacweb.ToolTip"));
            this.dpcacweb.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dpcacweb_LinkClicked);
            // 
            // dpad_DMSNET
            // 
            resources.ApplyResources(this.dpad_DMSNET, "dpad_DMSNET");
            this.dpad_DMSNET.BackColor = System.Drawing.SystemColors.Control;
            this.dpad_DMSNET.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dpad_DMSNET.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dpad_DMSNET.Name = "dpad_DMSNET";
            this.dpad_DMSNET.TabStop = true;
            this.toolTip.SetToolTip(this.dpad_DMSNET, resources.GetString("dpad_DMSNET.ToolTip"));
            this.dpad_DMSNET.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dpad_DMSNET_LinkClicked);
            // 
            // dpadlive
            // 
            resources.ApplyResources(this.dpadlive, "dpadlive");
            this.dpadlive.BackColor = System.Drawing.SystemColors.Control;
            this.dpadlive.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.dpadlive.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dpadlive.Name = "dpadlive";
            this.dpadlive.TabStop = true;
            this.dpadlive.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.dpadlive_LinkClicked);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.Car_insurance);
            this.groupBox3.Controls.Add(this.Email263);
            this.groupBox3.Controls.Add(this.SB_CS_pwd);
            this.groupBox3.Controls.Add(this.WX);
            this.groupBox3.Controls.Add(this.Importe);
            this.groupBox3.Controls.Add(this.financial_IMG);
            this.groupBox3.Controls.Add(this.Map);
            this.groupBox3.Controls.Add(this.financial);
            this.groupBox3.Controls.Add(this.TheTest);
            this.groupBox3.Controls.Add(this.EnterpriseMail);
            this.groupBox3.Controls.Add(this.UsedCar);
            this.groupBox3.Controls.Add(this.parts);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // Car_insurance
            // 
            resources.ApplyResources(this.Car_insurance, "Car_insurance");
            this.Car_insurance.BackColor = System.Drawing.SystemColors.Control;
            this.Car_insurance.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.Car_insurance.Name = "Car_insurance";
            this.Car_insurance.TabStop = true;
            this.toolTip.SetToolTip(this.Car_insurance, resources.GetString("Car_insurance.ToolTip"));
            this.Car_insurance.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Car_insurance_LinkClicked);
            // 
            // Email263
            // 
            resources.ApplyResources(this.Email263, "Email263");
            this.Email263.BackColor = System.Drawing.SystemColors.Control;
            this.Email263.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.Email263.Name = "Email263";
            this.Email263.TabStop = true;
            this.toolTip.SetToolTip(this.Email263, resources.GetString("Email263.ToolTip"));
            this.Email263.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Email263_LinkClicked);
            // 
            // SB_CS_pwd
            // 
            resources.ApplyResources(this.SB_CS_pwd, "SB_CS_pwd");
            this.SB_CS_pwd.BackColor = System.Drawing.SystemColors.Control;
            this.SB_CS_pwd.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.SB_CS_pwd.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.SB_CS_pwd.Name = "SB_CS_pwd";
            this.SB_CS_pwd.TabStop = true;
            this.SB_CS_pwd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SB_CS_pwd_LinkClicked);
            // 
            // WX
            // 
            resources.ApplyResources(this.WX, "WX");
            this.WX.BackColor = System.Drawing.SystemColors.Control;
            this.WX.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.WX.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.WX.Name = "WX";
            this.WX.TabStop = true;
            this.WX.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.WX_LinkClicked);
            // 
            // Importe
            // 
            resources.ApplyResources(this.Importe, "Importe");
            this.Importe.BackColor = System.Drawing.SystemColors.Control;
            this.Importe.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.Importe.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.Importe.Name = "Importe";
            this.Importe.TabStop = true;
            this.toolTip.SetToolTip(this.Importe, resources.GetString("Importe.ToolTip"));
            this.Importe.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Importe_LinkClicked);
            // 
            // financial_IMG
            // 
            resources.ApplyResources(this.financial_IMG, "financial_IMG");
            this.financial_IMG.BackColor = System.Drawing.SystemColors.Control;
            this.financial_IMG.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.financial_IMG.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.financial_IMG.Name = "financial_IMG";
            this.financial_IMG.TabStop = true;
            this.toolTip.SetToolTip(this.financial_IMG, resources.GetString("financial_IMG.ToolTip"));
            this.financial_IMG.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.financial_IMG_LinkClicked);
            // 
            // Map
            // 
            resources.ApplyResources(this.Map, "Map");
            this.Map.BackColor = System.Drawing.SystemColors.Control;
            this.Map.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.Map.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.Map.Name = "Map";
            this.Map.TabStop = true;
            this.toolTip.SetToolTip(this.Map, resources.GetString("Map.ToolTip"));
            this.Map.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Map_LinkClicked);
            // 
            // financial
            // 
            resources.ApplyResources(this.financial, "financial");
            this.financial.BackColor = System.Drawing.SystemColors.Control;
            this.financial.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.financial.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.financial.Name = "financial";
            this.financial.TabStop = true;
            this.toolTip.SetToolTip(this.financial, resources.GetString("financial.ToolTip"));
            this.financial.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.financial_LinkClicked);
            // 
            // TheTest
            // 
            resources.ApplyResources(this.TheTest, "TheTest");
            this.TheTest.BackColor = System.Drawing.SystemColors.Control;
            this.TheTest.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.TheTest.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.TheTest.Name = "TheTest";
            this.TheTest.TabStop = true;
            this.toolTip.SetToolTip(this.TheTest, resources.GetString("TheTest.ToolTip"));
            this.TheTest.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.TEST_LinkClicked);
            // 
            // EnterpriseMail
            // 
            resources.ApplyResources(this.EnterpriseMail, "EnterpriseMail");
            this.EnterpriseMail.BackColor = System.Drawing.SystemColors.Control;
            this.EnterpriseMail.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.EnterpriseMail.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.EnterpriseMail.Name = "EnterpriseMail";
            this.EnterpriseMail.TabStop = true;
            this.toolTip.SetToolTip(this.EnterpriseMail, resources.GetString("EnterpriseMail.ToolTip"));
            this.EnterpriseMail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.EnterpriseMail_LinkClicked);
            // 
            // UsedCar
            // 
            resources.ApplyResources(this.UsedCar, "UsedCar");
            this.UsedCar.BackColor = System.Drawing.SystemColors.Control;
            this.UsedCar.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.UsedCar.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.UsedCar.Name = "UsedCar";
            this.UsedCar.TabStop = true;
            this.toolTip.SetToolTip(this.UsedCar, resources.GetString("UsedCar.ToolTip"));
            this.UsedCar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.UsedCar_LinkClicked);
            // 
            // parts
            // 
            resources.ApplyResources(this.parts, "parts");
            this.parts.BackColor = System.Drawing.SystemColors.Control;
            this.parts.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.parts.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.parts.Name = "parts";
            this.parts.TabStop = true;
            this.toolTip.SetToolTip(this.parts, resources.GetString("parts.ToolTip"));
            this.parts.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.parts_LinkClicked);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.BtnEadd);
            this.groupBox4.Controls.Add(this.SetupMethods);
            this.groupBox4.Controls.Add(this.CWEBBACK1);
            this.groupBox4.Controls.Add(this.cwebbak);
            this.groupBox4.Controls.Add(this.Errinfo);
            this.groupBox4.Controls.Add(this.IESetting);
            this.groupBox4.Controls.Add(this.KeySetup);
            this.groupBox4.Controls.Add(this.cwebkey);
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.ForeColor = System.Drawing.Color.Red;
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            // 
            // BtnEadd
            // 
            resources.ApplyResources(this.BtnEadd, "BtnEadd");
            this.BtnEadd.Name = "BtnEadd";
            this.toolTip.SetToolTip(this.BtnEadd, resources.GetString("BtnEadd.ToolTip"));
            this.BtnEadd.UseVisualStyleBackColor = true;
            this.BtnEadd.Click += new System.EventHandler(this.BtnEadd_Click);
            // 
            // SetupMethods
            // 
            resources.ApplyResources(this.SetupMethods, "SetupMethods");
            this.SetupMethods.Name = "SetupMethods";
            this.toolTip.SetToolTip(this.SetupMethods, resources.GetString("SetupMethods.ToolTip"));
            this.SetupMethods.UseVisualStyleBackColor = true;
            this.SetupMethods.Click += new System.EventHandler(this.SetupMethods_Click);
            // 
            // CWEBBACK1
            // 
            resources.ApplyResources(this.CWEBBACK1, "CWEBBACK1");
            this.CWEBBACK1.Name = "CWEBBACK1";
            this.toolTip.SetToolTip(this.CWEBBACK1, resources.GetString("CWEBBACK1.ToolTip"));
            this.CWEBBACK1.UseVisualStyleBackColor = true;
            this.CWEBBACK1.Click += new System.EventHandler(this.CWEBBACK1_Click);
            // 
            // cwebbak
            // 
            resources.ApplyResources(this.cwebbak, "cwebbak");
            this.cwebbak.Name = "cwebbak";
            this.toolTip.SetToolTip(this.cwebbak, resources.GetString("cwebbak.ToolTip"));
            this.cwebbak.UseVisualStyleBackColor = true;
            this.cwebbak.Click += new System.EventHandler(this.cwebbak_Click);
            // 
            // Errinfo
            // 
            resources.ApplyResources(this.Errinfo, "Errinfo");
            this.Errinfo.Name = "Errinfo";
            this.toolTip.SetToolTip(this.Errinfo, resources.GetString("Errinfo.ToolTip"));
            this.Errinfo.UseVisualStyleBackColor = true;
            this.Errinfo.Click += new System.EventHandler(this.Errinfo_Click);
            // 
            // IESetting
            // 
            resources.ApplyResources(this.IESetting, "IESetting");
            this.IESetting.Name = "IESetting";
            this.toolTip.SetToolTip(this.IESetting, resources.GetString("IESetting.ToolTip"));
            this.IESetting.UseVisualStyleBackColor = true;
            this.IESetting.Click += new System.EventHandler(this.IESetting_Click);
            // 
            // KeySetup
            // 
            resources.ApplyResources(this.KeySetup, "KeySetup");
            this.KeySetup.Name = "KeySetup";
            this.toolTip.SetToolTip(this.KeySetup, resources.GetString("KeySetup.ToolTip"));
            this.KeySetup.UseVisualStyleBackColor = true;
            this.KeySetup.Click += new System.EventHandler(this.KeySetup_Click);
            // 
            // cwebkey
            // 
            resources.ApplyResources(this.cwebkey, "cwebkey");
            this.cwebkey.Name = "cwebkey";
            this.toolTip.SetToolTip(this.cwebkey, resources.GetString("cwebkey.ToolTip"));
            this.cwebkey.UseVisualStyleBackColor = true;
            this.cwebkey.Click += new System.EventHandler(this.cwebkey_Click);
            // 
            // button3
            // 
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.About_Click);
            // 
            // contxtMS
            // 
            this.contxtMS.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于程序,
            this.TSM_Display,
            this.TSM_Exit});
            this.contxtMS.Name = "contxtMS";
            resources.ApplyResources(this.contxtMS, "contxtMS");
            this.toolTip.SetToolTip(this.contxtMS, resources.GetString("contxtMS.ToolTip"));
            // 
            // 关于程序
            // 
            this.关于程序.Name = "关于程序";
            resources.ApplyResources(this.关于程序, "关于程序");
            this.关于程序.Click += new System.EventHandler(this.关于程序_Click);
            // 
            // TSM_Display
            // 
            this.TSM_Display.Name = "TSM_Display";
            resources.ApplyResources(this.TSM_Display, "TSM_Display");
            this.TSM_Display.Click += new System.EventHandler(this.TSM_Display_Click);
            // 
            // TSM_Exit
            // 
            this.TSM_Exit.Name = "TSM_Exit";
            resources.ApplyResources(this.TSM_Exit, "TSM_Exit");
            this.TSM_Exit.Click += new System.EventHandler(this.TSM_Exit_Click);
            // 
            // notifyIcon
            // 
            this.notifyIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon.ContextMenuStrip = this.contxtMS;
            resources.ApplyResources(this.notifyIcon, "notifyIcon");
            this.notifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon_MouseDoubleClick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于ToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            resources.ApplyResources(this.toolStripMenuItem2, "toolStripMenuItem2");
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            resources.ApplyResources(this.关于ToolStripMenuItem, "关于ToolStripMenuItem");
            this.关于ToolStripMenuItem.Click += new System.EventHandler(this.关于ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel6,
            this.toolStripStatusLabel8,
            this.toolStripStatusLabel9,
            this.toolStripStatusLabel7});
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            resources.ApplyResources(this.toolStripStatusLabel1, "toolStripStatusLabel1");
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            resources.ApplyResources(this.toolStripStatusLabel2, "toolStripStatusLabel2");
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            resources.ApplyResources(this.toolStripStatusLabel3, "toolStripStatusLabel3");
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            resources.ApplyResources(this.toolStripStatusLabel4, "toolStripStatusLabel4");
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            resources.ApplyResources(this.toolStripStatusLabel5, "toolStripStatusLabel5");
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            resources.ApplyResources(this.toolStripStatusLabel6, "toolStripStatusLabel6");
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            resources.ApplyResources(this.toolStripStatusLabel7, "toolStripStatusLabel7");
            // 
            // toolStripStatusLabel8
            // 
            this.toolStripStatusLabel8.Name = "toolStripStatusLabel8";
            resources.ApplyResources(this.toolStripStatusLabel8, "toolStripStatusLabel8");
            // 
            // toolStripStatusLabel9
            // 
            this.toolStripStatusLabel9.Name = "toolStripStatusLabel9";
            resources.ApplyResources(this.toolStripStatusLabel9, "toolStripStatusLabel9");
            // 
            // FrMain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Perfect_Visual_神龙信息经理辅助.Properties.Resources.hbd;
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel2);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "FrMain";
            this.toolTip.SetToolTip(this, resources.GetString("$this.ToolTip"));
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrMain_FormClosed);
            this.Load += new System.EventHandler(this.FrMain_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.contxtMS.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.LinkLabel dcadGW;
        private System.Windows.Forms.LinkLabel dcadIQS;
        private System.Windows.Forms.LinkLabel dcadReply;
        private System.Windows.Forms.LinkLabel dcad_cs;
        private System.Windows.Forms.LinkLabel salesjob;
        private System.Windows.Forms.LinkLabel dcadlive;
        private System.Windows.Forms.LinkLabel dcad_DMSNET;
        private System.Windows.Forms.LinkLabel dcadcweb;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.LinkLabel DPAD_NetDisk;
        private System.Windows.Forms.LinkLabel dpadGW;
        private System.Windows.Forms.LinkLabel dpadIQS;
        private System.Windows.Forms.LinkLabel dpad_Opp;
        private System.Windows.Forms.LinkLabel dpadReply;
        private System.Windows.Forms.LinkLabel dpadSB;
        private System.Windows.Forms.LinkLabel dpcacweb;
        private System.Windows.Forms.LinkLabel dpad_DMSNET;
        private System.Windows.Forms.LinkLabel dpadlive;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.LinkLabel Car_insurance;
        private System.Windows.Forms.LinkLabel Email263;
        private System.Windows.Forms.LinkLabel WX;
        private System.Windows.Forms.LinkLabel Importe;
        private System.Windows.Forms.LinkLabel Map;
        private System.Windows.Forms.LinkLabel financial;
        private System.Windows.Forms.LinkLabel TheTest;
        private System.Windows.Forms.LinkLabel EnterpriseMail;
        private System.Windows.Forms.LinkLabel UsedCar;
        private System.Windows.Forms.LinkLabel parts;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button CWEBBACK1;
        private System.Windows.Forms.Button cwebbak;
        private System.Windows.Forms.Button Errinfo;
        private System.Windows.Forms.Button IESetting;
        private System.Windows.Forms.Button KeySetup;
        private System.Windows.Forms.Button cwebkey;
        private System.Windows.Forms.LinkLabel DCAD_NetDisk;
        private System.Windows.Forms.Button SetupMethods;
        private System.Windows.Forms.LinkLabel financial_IMG;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ContextMenuStrip contxtMS;
        private System.Windows.Forms.ToolStripMenuItem TSM_Display;
        private System.Windows.Forms.ToolStripMenuItem TSM_Exit;
        private System.Windows.Forms.Button BtnEadd;
        private System.Windows.Forms.Button Start1;
        private System.Windows.Forms.Button Start2;
        private System.Windows.Forms.Button btnTools;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button Setting;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem 关于程序;
        private System.Windows.Forms.Button btnOpne;
        private System.Windows.Forms.Button btnWIN8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.LinkLabel Lbcopy;
        private System.Windows.Forms.LinkLabel SB_CS_pwd;
        private System.Windows.Forms.Button btnpwd;
        private System.Windows.Forms.Button btnetkey;
        internal System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel8;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel9;
    }
}

