﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Perfect_Visual_神龙信息经理辅助
{
    [Serializable]
   public class Pinfo_class
    {
        public string P_Code { get; set; }
        public string P_Info { get; set; }
        public string P_Answer { get; set; }
    }
     
}
